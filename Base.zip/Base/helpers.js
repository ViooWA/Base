require('./lib/settings/config')
const fs = require('fs')
const moment = require('moment-timezone')
const path = require('path')
const util = require('util')
const { exec } = require('child_process')

const own = JSON.parse(fs.readFileSync('./data/owner.json').toString())
const prem = JSON.parse(fs.readFileSync('./data/premium.json'))

module.exports = sock = async (sock, m, chatUpdate, mek, store) => {
try {

const { parseMention, getRandom, getBuffer, fetchJson, sleep, isUrl, getTime, getGroupAdmins, pickRandom } = require('./lib/myfunc')
var body = m.body
var budy = m.text
const prefix = /^[!#.]/.test(body) ? body.match(/^[!#.]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(1).trim().split(' ').shift().toLowerCase() : ''
const pushname = m.pushName || "No Name"
const botNumber = await sock.decodeJid(sock.user.id)
const wibTime = moment().tz('Asia/Jakarta').format('HH:mm:ss')

const isOwner = [owner, botNumber, ...own]
.filter(v => typeof v === 'string' && v.trim() !== '')
.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
.includes(m.sender)
const isPremium = [owner, botNumber, ...own, prem]
.filter(v => typeof v === 'string' && v.trim() !== '') 
.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
.includes(m.sender)

if (budy.startsWith('> ')) {
if (!isOwner) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(util.format(err))
}}

if (budy.startsWith('$ ')) {
if (!isOwner) return 
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})}

const args = body.trim().split(/ +/).slice(1)
const full_args = body.replace(command, '').slice(1).trim()
const text = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const from = m.key.remoteJid
const mime = (quoted.msg || quoted).mimetype || ''
const isMedia = /image|video|sticker|audio/.test(mime)
const isPc = from.endsWith('@s.whatsapp.net')
const isGc = from.endsWith('@g.us')
const qmsg = (quoted.msg || quoted)
const isGroup = from.endsWith('@g.us')
const sender = m.key.fromMe ? (sock.user.id.split(':')[0]+'@s.whatsapp.net' || sock.user.id) : (m.key.participant || m.key.remoteJid)
const senderNumber = sender.split('@')[0]
const isBot = botNumber.includes(senderNumber)
const groupMetadata = m.isGroup ? await sock.groupMetadata(m.chat) :''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await participants.filter((v) => v.admin !== null).map((i) => i.id) : [] || [];
const groupOwner = m.isGroup ? groupMetadata?.owner : false;
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false;
const groupMembers = isGroup ? groupMetadata.participants : ''

if (wibTime < "23:59:59"){ var ucapanWaktu = 'Selamat malam'}
if (wibTime < "19:00:00"){ var ucapanWaktu = 'Selamat malam'}
if (wibTime < "18:00:00"){ var ucapanWaktu = 'Selamat sore'}
if (wibTime < "14:59:59"){ var ucapanWaktu = 'Selamat siang'}
if (wibTime < "10:00:00"){ var ucapanWaktu = 'Selamat pagi'}
if (wibTime < "06:00:00"){ var ucapanWaktu = 'Selamat pagi'}

try {
let isNumber = x => typeof x === 'number' && !isNaN(x)
let user = global.db.data.users[m.sender]
if (typeof user !== 'object') global.db.data.users[m.sender] = {}
if (user) {
if (!('nama' in user)) user.nama = `${pushname}`
} else global.db.data.users[m.sender] = {
nama: `${pushname}`
}} catch(err) {
console.log('')
}

fs.writeFileSync('./data/database.json', JSON.stringify(global.db.data, null, 2))

sock.ments = (teks = '') => {
return teks.match('@') ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : []}

const reply = (teks) => {
return sock.sendMessage(m.chat, { text: teks, mentions: sock.ments(teks) }, {quoted: m})}

const floc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Powered by sock`,jpegThumbnail: ''}}}

//==========================

const Owner = () => {
m.reply(mess.owner)
}
const Premium = () => {
m.reply(mess.prem)
}
const Group = () => {
m.reply(mess.grup)
}
const Private = () => {
m.reply(mess.privat)
}
const Admins = () => {
m.reply(mess.admin)
}
const BotAdmins = () => {
m.reply(mess.botadmin)
}

if (budy === '.menu') {
const teks = `Hi, I'm V-APIs which was created to help someone in their personality, I was released by api-vioo.my.id who is ready for you!

*User Information*
• Name: ${db.data.users[m.sender].nama}
• Status: ${isOwner ? 'owner' : isPremium ? 'premium' : 'user'}

*Bot Information*
• Name: ${botname}
• Status: online

${listMenu}

*© 2024 V-APIs*`;
sock.sendMessage(m.chat, {
text: teks,
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
title: "V-APIs Scripts",
body: ucapanWaktu + " kak 👋",
thumbnailUrl: "https://pomf2.lain.la/f/7udnlgb.jpg",
mediaType: 2,
mediaUrl: "https://api-vioo.my.id/",
sourceUrl: "https://api-vioo.my.id/"
}}}, {quoted: floc});
}

switch (command) {

// ==========================

case 'sock': {
m.reply('Sock')
}
break

// ==========================

default: }

} catch (err) {
console.log(util.format(err))
let e = String(err)
lastErrorSentTime = currentTime
sock.sendMessage(owner + '@s.whatsapp.net', {
text: "Hi developer, tolong perbaiki beberapa ini\n\n" + util.format(err)
})
}}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)})